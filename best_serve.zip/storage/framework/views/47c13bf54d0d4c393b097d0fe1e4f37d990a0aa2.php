<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
      <img src="<?php echo e(asset('material')); ?>/img/logo.png" width="100px" height="100px">
      <?php echo e(__('Best Service')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
          <i class="material-icons">person</i>
            <p><?php echo e(__('Your Profile')); ?></p>
        </a>
      </li>
      <?php if(auth()->user()->isAdmin()): ?>
      <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
          <i class="material-icons">people</i>
            <p><?php echo e(__('User Management')); ?></p>
        </a>
      </li>
      <?php endif; ?>
      <li class="nav-item<?php echo e($activePage == 'blacklist' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('blacklist.index')); ?>">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Black Lists')); ?></p>
        </a>
      </li>

    </ul>
  </div>
</div><?php /**PATH D:\Web\Larabel\best_serve\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>