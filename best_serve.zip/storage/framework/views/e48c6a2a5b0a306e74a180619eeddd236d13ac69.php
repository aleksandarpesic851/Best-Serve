<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-md-6">
          <div class="card card-chart">
            <div class="card-header card-header-success">
              <div class="ct-chart" id="userChat"></div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Registered Users - <span class="text-success"> <?php echo e($totalUser); ?> </span> </h4>
            </div>
            <div class="card-footer">
              <div class="stats">
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card card-chart">
            <div class="card-header card-header-warning">
              <div class="ct-chart" id="blackChart"></div>
            </div>
            <div class="card-body">
              <h4 class="card-title">Reported Black Lists - <span class="text-success"> <?php echo e($totalBlacklist); ?> </span></h4>
            </div>
            <div class="card-footer">
              <div class="stats">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
       
        <div class="card">
          <div class="card-header card-header-warning">
            <h4 class="card-title">Latest Black Lists</h4>
            <p class="card-category">New 5 Black lists, reported by users</p>
          </div>
          <div class="card-body table-responsive">
            <table class="table table-hover">
              <thead class="text-warning">
                <th>No</th>
                <th>Photo</th>
                <th>Name</th>
                <th>Country</th>
              </thead>
              <tbody>
              <?php $i = 0;?>
              <?php $__currentLoopData = $blacklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blacklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i++; ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <?php if($blacklist->avatar): ?>
                  <td><img src="/uploads/blacklists/<?php echo e($blacklist->avatar); ?>" class="avatar-blacklist"></td>
                  <?php else: ?>
                  <td><img src="/material/img/user.png" class="avatar-blacklist"></td>
                  <?php endif; ?>
                  <td><?php echo e($blacklist->full_name); ?></td>
                  <td><?php echo e($blacklist->country_residence); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script>
    <?php
    echo "const userVal = ". json_encode($userVal) . ";\n";
    echo "const dateVal = ". json_encode($dateVal) . ";\n";
    echo "const blackVal = ". json_encode($blackVal) . ";\n";
    ?>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web\Larabel\best_serve\resources\views/dashboard.blade.php ENDPATH**/ ?>