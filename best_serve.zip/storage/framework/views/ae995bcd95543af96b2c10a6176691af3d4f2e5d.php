<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form enctype="multipart/form-data" method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Edit Profile')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <div class="col-sm-4">
                    <div class="row " style=" min-height: 100%; align-items: center;">
                      <img class="avatar-image" id="avatar_image" src="/uploads/avatars/<?php echo e(old('avatar', auth()->user()->avatar)); ?>">
                    </div>
                    <input id="avatar" type="file" name="avatar" style="display: none" onchange="updateAvatarImage(this)">
                  </div>

                  <div class="col-sm-8">
                    <div class="row">
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Name')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="input-name" type="text" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" required="true" aria-required="true"/>
                          <?php if($errors->has('name')): ?>
                            <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('name')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', auth()->user()->email)); ?>" required />
                          <?php if($errors->has('email')): ?>
                            <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Company')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('company') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('company') ? ' is-invalid' : ''); ?>" name="company" id="input-company" type="text" placeholder="<?php echo e(__('Company')); ?>" value="<?php echo e(old('company', auth()->user()->company)); ?>" required />
                          <?php if($errors->has('company')): ?>
                            <span id="company-error" class="error text-danger" for="input-company"><?php echo e($errors->first('company')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-2 col-form-label"><?php echo e(__('Contact')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('contact') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>" name="contact" id="input-contact" type="contact" placeholder="<?php echo e(__('Contact')); ?>" value="<?php echo e(old('contact', auth()->user()->contact)); ?>" />
                          <?php if($errors->has('contact')): ?>
                            <span id="contact-error" class="error text-danger" for="input-contact"><?php echo e($errors->first('contact')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('profile.password')); ?>" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Change password')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status_password')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status_password')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Current Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" input type="password" name="old_password" id="input-current-password" placeholder="<?php echo e(__('Current Password')); ?>" value="" required />
                      <?php if($errors->has('old_password')): ?>
                        <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('old_password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password"><?php echo e(__('New Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="input-password" type="password" placeholder="<?php echo e(__('New Password')); ?>" value="" required />
                      <?php if($errors->has('password')): ?>
                        <span id="password-error" class="error text-danger" for="input-password"><?php echo e($errors->first('password')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-password-confirmation"><?php echo e(__('Confirm New Password')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control" name="password_confirmation" id="input-password-confirmation" type="password" placeholder="<?php echo e(__('Confirm New Password')); ?>" value="" required />
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Change password')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script type="text/javascript">
    $(document).ready(function() {
      $('#avatar_image').click(function() {
        $('#avatar').click();
      });
    });

    function createObjectURL(object) {
      return (window.URL) ? window.URL.createObjectURL(object) : window.webkitURL.createObjectURL(object);
    }

    function updateAvatarImage(input) {
      const avatarImage = document.getElementById('avatar_image');
      const file = input.files[0];
      avatarImage.src = createObjectURL(file);
      avatarImage.onload = function() {
            window.URL.revokeObjectURL(this.src);
        }

    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'profile', 'titlePage' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web\Larabel\best_serve\resources\views/profile/edit.blade.php ENDPATH**/ ?>