<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form enctype="multipart/form-data" method="post" action="<?php echo e(route('blacklist.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Report To Black List')); ?></h4>
                <p class="card-category"></p>
              </div>
              <div class="card-body ">
                <div class="row">
                  <div class="col-md-12 text-right">
                      <a href="<?php echo e(route('user.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                  </div>
                </div>
                
                <div class="row">

                  <div class="col-sm-4">
                    <div class="row " style=" min-height: 100%; align-items: center;">
                      <img class="avatar-image" id="avatar_image" src="/uploads/avatars/user.png">
                    </div>
                    <input id="avatar" type="file" name="avatar" style="display: none" onchange="updateAvatarImage(this)">
                  </div>

                  <div class="col-sm-8">

                    <div class="row">
                      <label class="col-sm-3 col-form-label"><?php echo e(__('Full Name')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('full_name') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('full_name') ? ' is-invalid' : ''); ?>" name="full_name" id="input-full_name" type="text" placeholder="<?php echo e(__('Full Name')); ?>" value="<?php echo e(old('full_name')); ?>" required="true" aria-required="true"/>
                          <?php if($errors->has('full_name')): ?>
                            <span id="full_name-error" class="error text-danger" for="input-full_name"><?php echo e($errors->first('name')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-3 col-form-label" for="input-business"><?php echo e(__(' Business')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('business') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('business') ? ' is-invalid' : ''); ?>" input type="text" name="business" id="input-business" placeholder="<?php echo e(__('Business')); ?>" value="" required />
                          <?php if($errors->has('business')): ?>
                            <span id="business-error" class="error text-danger" for="input-business"><?php echo e($errors->first('business')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-3 col-form-label" for="input-birthday"><?php echo e(__('Birthday')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group">
                          <input class="form-control" data-toggle="datepicker" name="birthday" id="input-birthday" type="text" placeholder="<?php echo e(__('Birthday')); ?>" value="" required />
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-3 col-form-label"><?php echo e(__('Nationality')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('nationality') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" name="nationality" id="input-nationality" type="text" placeholder="<?php echo e(__('Nationality')); ?>" value="<?php echo e(old('nationality')); ?>" required />
                          <?php if($errors->has('nationality')): ?>
                            <span id="nationality-error" class="error text-danger" for="input-nationality"><?php echo e($errors->first('nationality')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <label class="col-sm-3 col-form-label"><?php echo e(__('National Id Card Number')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('national_id_card_no') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('national_id_card_no') ? ' is-invalid' : ''); ?>" name="national_id_card_no" id="input-national_id_card_no" type="text" placeholder="<?php echo e(__('National Id Card Number')); ?>" value="<?php echo e(old('national_id_card_no')); ?>" />
                          <?php if($errors->has('national_id_card_no')): ?>
                            <span id="national_id_card_no-error" class="error text-danger" for="input-national_id_card_no"><?php echo e($errors->first('national_id_card_no')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-3 col-form-label"><?php echo e(__('Social Security Number')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('social_security_no') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('social_security_no') ? ' is-invalid' : ''); ?>" name="social_security_no" id="input-social_security_no" type="text" placeholder="<?php echo e(__('Social Security Number')); ?>" value="<?php echo e(old('social_security_no')); ?>" />
                          <?php if($errors->has('social_security_no')): ?>
                            <span id="social_security_no-error" class="error text-danger" for="input-social_security_no"><?php echo e($errors->first('social_security_no')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-3 col-form-label"><?php echo e(__('Country Residence')); ?></label>
                      <div class="col-sm-7">
                        <div class="form-group<?php echo e($errors->has('country_residence') ? ' has-danger' : ''); ?>">
                          <input class="form-control<?php echo e($errors->has('country_residence') ? ' is-invalid' : ''); ?>" name="country_residence" id="input-country_residence" type="text" placeholder="<?php echo e(__('Country Residence')); ?>" value="<?php echo e(old('country_residence')); ?>" />
                          <?php if($errors->has('country_residence')): ?>
                            <span id="country_residence-error" class="error text-danger" for="input-country_residence"><?php echo e($errors->first('country_residence')); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

                <div class="row">
                  <div class="col-sm-6">

                    <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Zip Code')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('zip_code') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('zip_code') ? ' is-invalid' : ''); ?>" name="zip_code" id="input-zip_code" type="text" placeholder="<?php echo e(__('Zip Code')); ?>" value="<?php echo e(old('zip_code')); ?>" />
                            <?php if($errors->has('zip_code')): ?>
                              <span id="zip_code-error" class="error text-danger" for="input-zip_code"><?php echo e($errors->first('zip_code')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('First Name')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('firstname') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" id="input-firstname" type="text" placeholder="<?php echo e(__('First Name')); ?>" value="<?php echo e(old('firstname')); ?>" />
                            <?php if($errors->has('firstname')): ?>
                              <span id="firstname-error" class="error text-danger" for="input-firstname"><?php echo e($errors->first('firstname')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Maiden Name')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('maidenname') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('maidenname') ? ' is-invalid' : ''); ?>" name="maidenname" id="input-maidenname" type="text" placeholder="<?php echo e(__('Maiden Name')); ?>" value="<?php echo e(old('maidenname')); ?>" />
                            <?php if($errors->has('maidenname')): ?>
                              <span id="maidenname-error" class="error text-danger" for="input-maidenname"><?php echo e($errors->first('maidenname')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Country of Birth')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('country_birth') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('country_birth') ? ' is-invalid' : ''); ?>" name="country_birth" id="input-country_birth" type="text" placeholder="<?php echo e(__('Country of Birth')); ?>" value="<?php echo e(old('country_birth')); ?>" />
                            <?php if($errors->has('country_birth')): ?>
                              <span id="country_birth-error" class="error text-danger" for="input-country_birth"><?php echo e($errors->first('country_birth')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                       <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Color of Eye')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('color_eye') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('color_eye') ? ' is-invalid' : ''); ?>" name="color_eye" id="input-color_eye" type="text" placeholder="<?php echo e(__('Color of Eye')); ?>" value="<?php echo e(old('color_eye')); ?>" />
                            <?php if($errors->has('color_eye')): ?>
                              <span id="color_eye-error" class="error text-danger" for="input-color_eye"><?php echo e($errors->first('color_eye')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Visible Peculiarity')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('visible_peculiarity') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('visible_peculiarity') ? ' is-invalid' : ''); ?>" name="visible_peculiarity" id="input-visible_peculiarity" type="text" placeholder="<?php echo e(__('Visible Peculiarity')); ?>" value="<?php echo e(old('visible_peculiarity')); ?>" />
                            <?php if($errors->has('visible_peculiarity')): ?>
                              <span id="visible_peculiarity-error" class="error text-danger" for="input-visible_peculiarity"><?php echo e($errors->first('visible_peculiarity')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Profession')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('profession') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('profession') ? ' is-invalid' : ''); ?>" name="profession" id="input-profession" type="text" placeholder="<?php echo e(__('Profession')); ?>" value="<?php echo e(old('profession')); ?>" />
                            <?php if($errors->has('profession')): ?>
                              <span id="profession-error" class="error text-danger" for="input-profession"><?php echo e($errors->first('profession')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                       <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Surburb')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('surburb') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('surburb') ? ' is-invalid' : ''); ?>" name="surburb" id="input-surburb" type="text" placeholder="<?php echo e(__('Surburb')); ?>" value="<?php echo e(old('surburb')); ?>" />
                            <?php if($errors->has('surburb')): ?>
                              <span id="surburb-error" class="error text-danger" for="input-surburb"><?php echo e($errors->first('surburb')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Telephone Number')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('telephone_no') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('telephone_no') ? ' is-invalid' : ''); ?>" name="telephone_no" id="input-telephone_no" type="text" placeholder="<?php echo e(__('Telephone Number')); ?>" value="<?php echo e(old('telephone_no')); ?>" />
                            <?php if($errors->has('telephone_no')): ?>
                              <span id="telephone_no-error" class="error text-danger" for="input-telephone_no"><?php echo e($errors->first('telephone_no')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                       <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Phone Number')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('phone_no') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('phone_no') ? ' is-invalid' : ''); ?>" name="phone_no" id="input-phone_no" type="text" placeholder="<?php echo e(__('Phone Number')); ?>" value="<?php echo e(old('phone_no')); ?>" />
                            <?php if($errors->has('phone_no')): ?>
                              <span id="phone_no-error" class="error text-danger" for="input-phone_no"><?php echo e($errors->first('phone_no')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                  </div>

                  <div class="col-sm-6">

                    <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Surname')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('surname') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" id="input-surname" type="text" placeholder="<?php echo e(__('Surname')); ?>" value="<?php echo e(old('surname')); ?>" />
                            <?php if($errors->has('surname')): ?>
                              <span id="surname-error" class="error text-danger" for="input-surname"><?php echo e($errors->first('surname')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                    </div>

                    <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Other Name')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('othername') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('othername') ? ' is-invalid' : ''); ?>" name="othername" id="input-othername" type="text" placeholder="<?php echo e(__('othername')); ?>" value="<?php echo e(old('Other Name')); ?>" />
                            <?php if($errors->has('othername')): ?>
                              <span id="othername-error" class="error text-danger" for="input-othername"><?php echo e($errors->first('othername')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('City of Birth')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('city_birth') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('city_birth') ? ' is-invalid' : ''); ?>" name="city_birth" id="input-city_birth" type="text" placeholder="<?php echo e(__('City of Birth')); ?>" value="<?php echo e(old('city_birth')); ?>" />
                            <?php if($errors->has('city_birth')): ?>
                              <span id="city_birth-error" class="error text-danger" for="input-city_birth"><?php echo e($errors->first('city_birth')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Height')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('height') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('height') ? ' is-invalid' : ''); ?>" name="height" id="input-height" type="text" placeholder="<?php echo e(__('Height')); ?>" value="<?php echo e(old('height')); ?>" />
                            <?php if($errors->has('height')): ?>
                              <span id="height-error" class="error text-danger" for="input-height"><?php echo e($errors->first('height')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Color of Hair')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('color_hair') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('color_hair') ? ' is-invalid' : ''); ?>" name="color_hair" id="input-color_hair" type="text" placeholder="<?php echo e(__('Color of Hair')); ?>" value="<?php echo e(old('color_hair')); ?>" />
                            <?php if($errors->has('color_hair')): ?>
                              <span id="color_hair-error" class="error text-danger" for="input-color_hair"><?php echo e($errors->first('color_hair')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Marital Status')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('marital_status') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('marital_status') ? ' is-invalid' : ''); ?>" name="marital_status" id="input-marital_status" type="text" placeholder="<?php echo e(__('Marital Status')); ?>" value="<?php echo e(old('marital_status')); ?>" />
                            <?php if($errors->has('marital_status')): ?>
                              <span id="marital_status-error" class="error text-danger" for="input-marital_status"><?php echo e($errors->first('marital_status')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('City Residence')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('city_residence') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('city_residence') ? ' is-invalid' : ''); ?>" name="city_residence" id="input-city_residence" type="text" placeholder="<?php echo e(__('City Residence')); ?>" value="<?php echo e(old('city_residence')); ?>" />
                            <?php if($errors->has('city_residence')): ?>
                              <span id="city_residence-error" class="error text-danger" for="input-city_residence"><?php echo e($errors->first('city_residence')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Postal Address')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('postal_address') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('postal_address') ? ' is-invalid' : ''); ?>" name="postal_address" id="input-postal_address" type="text" placeholder="<?php echo e(__('Postal Address')); ?>" value="<?php echo e(old('postal_address')); ?>" />
                            <?php if($errors->has('postal_address')): ?>
                              <span id="postal_address-error" class="error text-danger" for="input-postal_address"><?php echo e($errors->first('postal_address')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <label class="col-sm-3 col-form-label"><?php echo e(__('Email')); ?></label>
                        <div class="col-sm-7">
                          <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email')); ?>" required />
                            <?php if($errors->has('email')): ?>
                              <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>

                  </div>
                </div>
              </div>

              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Report to Black List')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<link  href="/material/datepicker/datepicker.css" rel="stylesheet">
<script src="/material/datepicker/datepicker.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
      $('#avatar_image').click(function() {
        $('#avatar').click();
      });
      $('[data-toggle="datepicker"]').datepicker();
    });

    function createObjectURL(object) {
      return (window.URL) ? window.URL.createObjectURL(object) : window.webkitURL.createObjectURL(object);
    }

    function updateAvatarImage(input) {
      const avatarImage = document.getElementById('avatar_image');
      const file = input.files[0];
      avatarImage.src = createObjectURL(file);
      avatarImage.onload = function() {
            window.URL.revokeObjectURL(this.src);
        }

    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'blacklist-management', 'titlePage' => __('Blacklist Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web\Larabel\best_serve\resources\views/blacklist/create.blade.php ENDPATH**/ ?>