<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card ">

                    <div class="card-header card-header-primary">
                        <h4 class="card-title"><?php echo e(__('Report To Black List')); ?></h4>
                        <p class="card-category"></p>
                    </div>
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-md-12 text-right">
                                <a href="<?php echo e(route('blacklist.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                            
                        <div class="row">

                            <div class="col-sm-4">
                                <div class="row " style=" min-height: 100%; align-items: center;">
                                    <img class="avatar-image" id="avatar_image" src="/uploads/blacklists/<?php echo e(old('avatar', $blacklist->avatar)); ?>">
                                </div>
                            </div>

                            <div class="col-sm-8">

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Full Name')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('full_name', $blacklist->full_name)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Business')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('business', $blacklist->business)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Birthday')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('birthday', $blacklist->birthday)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Nationality')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('nationality', $blacklist->nationality)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('National Id Card Number')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('national_id_card_no', $blacklist->national_id_card_no)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Social Security Number')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('social_security_no', $blacklist->social_security_no)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Country Residence')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('country_residence', $blacklist->country_residence)); ?></h3>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="row">
                        
                            <div class="col-sm-6">

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Zip Code')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('zip_code', $blacklist->zip_code)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Full Name')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('full_name', $blacklist->full_name)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('First Name')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('firstname', $blacklist->firstname)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Maiden Name')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('maidenname', $blacklist->maidenname)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Country of Birth')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('country_birth', $blacklist->country_birth)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Color of Eye')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('color_eye', $blacklist->color_eye)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Visible Peculiarity')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('visible_peculiarity', $blacklist->visible_peculiarity)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Profession')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('profession', $blacklist->profession)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Surburb')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('surburb', $blacklist->surburb)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Telephone Number')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('telephone_no', $blacklist->telephone_no)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Phone Number')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('phone_no', $blacklist->phone_no)); ?></h3>
                                    </div>
                                </div>

                            </div>

                            <div class="col-sm-6">

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Surname')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('surname', $blacklist->surname)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Surname')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('surname', $blacklist->surname)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Other Name')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('othername', $blacklist->othername)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('City of Birth')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('city_birth', $blacklist->city_birth)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Height')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('height', $blacklist->height)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Color of Hair')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('color_hair', $blacklist->color_hair)); ?></h3>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Marital Status')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('marital_status', $blacklist->marital_status)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('City Residence')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('city_residence', $blacklist->city_residence)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Postal Address')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('postal_address', $blacklist->postal_address)); ?></h3>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-3 col-form-label"><?php echo e(__('Email')); ?></label>
                                    <div class="col-sm-7">
                                        <h3 class="blackinformation"><?php echo e(old('email', $blacklist->email)); ?></h3>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'blacklist-management', 'titlePage' => __('Blacklist Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web\Larabel\best_serve\resources\views/blacklist/show.blade.php ENDPATH**/ ?>